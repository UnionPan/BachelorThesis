# coding=utf-8
from utils.file_operation import read_file
from utils.file_operation import write_file
from utils.rosette_api import api
from nltk.tokenize import word_tokenize
from utils.parse_xml import ParseXML
from utils.log_custom import log
from pre_processing.generate_hlda_model import model_temp
import os
import time


def __processing_using_ros(original_path="../data/MultiLing2015-MSS/multilingMss2015Eval/body/xml",
                           data_backup_path="../data/MultiLing2015-MSS-ROS/eval_with_stop_token_with_title"):
    px = ParseXML()
    for lang in os.listdir(original_path):
        if lang != "th":
            continue
        if lang in ["ar", "cs", "de", "el", "en", "es", "fa", "fr", "he", "hu", "it", "ja", "ko",
                    "nl", "no", "pl", "pt", "ro", "ru", "sv", "th", "tr", "zh"]:
            print lang
            lang_path = os.path.join("%s/%s" % (original_path, lang))
            for cur_file in os.listdir(lang_path):
                print cur_file
                dir_name = cur_file.split("_")[0]
                out_lang_path = os.path.join("%s/%s/%s/" % (data_backup_path, lang, dir_name))
                if os.path.exists(out_lang_path + "/tokenized_body.temp") and \
                        os.path.exists(out_lang_path + "/tokenized_title.temp") and False:
                    continue
                if not os.path.exists(out_lang_path):
                    os.makedirs(out_lang_path)
                px.parse(os.path.join("%s/%s" % (lang_path, cur_file)))
                # cur_content = read_file(os.path.join("%s/%s" % (lang_path, cur_file)))
                contents = px.all_content
                titles = px.title
                if lang in ["ar", "cs", "de", "el", "en", "es", "fr", "hu", "it", "ja", "ko",
                    "nl", "no", "pl", "pt", "ro", "ru", "sv", "th", "zh"]:
                    word_segmented, lemmas = api.lemmatize(u" ".join(contents))
                    write_file(contents, os.path.join("%s/%s.txt" % (out_lang_path, dir_name)), False)
                    write_file(word_segmented, out_lang_path + "/tokenized_body.temp", False)
                    write_file(lemmas, out_lang_path + "/lemmatized_body.temp", False)
                    if cur_file == "4ef8edf092432b9969cf0973227ed603_body.xml":
                        tmp_segmented, temp_lemmas = api.lemmatize(u" ".join(contents + titles))
                        write_file(tmp_segmented[len(word_segmented):], out_lang_path + "/tokenized_title.temp", False)
                        write_file(temp_lemmas[len(lemmas):], out_lang_path + "/lemmatized_title.temp", False)
                        continue
                    word_segmented, lemmas = api.lemmatize(u" ".join(titles))
                    write_file(word_segmented, out_lang_path + "/tokenized_title.temp", False)
                    write_file(lemmas, out_lang_path + "/lemmatized_title.temp", False)
                else:
                    word_segmented = api.tokenize(u" ".join(contents))
                    write_file(contents, os.path.join("%s/%s.txt" % (out_lang_path, dir_name)), False)
                    write_file(word_segmented, out_lang_path + "/tokenized_body.temp", False)
                    write_file(word_segmented, out_lang_path + "/lemmatized_body.temp", False)
                    word_segmented = api.tokenize(u" ".join(titles))
                    write_file(word_segmented, out_lang_path + "/tokenized_title.temp", False)
                    write_file(word_segmented, out_lang_path + "/lemmatized_title.temp", False)


def __processing_using_nltk(original_path="./data/MultiLing2015-MSS/multilingMss2015Eval/body/xml",
                            data_backup_path="./data/MultiLing2015-MSS-ROS/eval_with_stop_token_with_title"):
    px = ParseXML()
    for lang in os.listdir(original_path):
        if lang in ["af", "bg", "ca", "eo", "eu", "fi", "hr", "id", "ka", "ms", "sh", "sk", "sl", "sr", "vi"]:
            print lang
            lang_path = os.path.join("%s/%s" % (original_path, lang))
            for cur_file in os.listdir(lang_path):
                dir_name = cur_file.split("_")[0]
                out_lang_path = os.path.join("%s/%s/%s/" % (data_backup_path, lang, dir_name))
                if not os.path.exists(out_lang_path):
                    os.makedirs(out_lang_path)
                px.parse(os.path.join("%s/%s" % (lang_path, cur_file)))
                contents = px.text
                titles = px.title
                word_segmented = word_tokenize(" ".join(contents))
                write_file(contents, os.path.join("%s/%s.txt" % (out_lang_path, dir_name)), False)
                write_file(word_segmented, out_lang_path + "/tokenized_paper.temp", False)
                write_file(word_segmented, out_lang_path + "/lemmatized_paper.temp", False)
                write_file(word_tokenize(" ".join(titles)), out_lang_path + "/tokenized_title.temp", False)
                write_file(word_tokenize(" ".join(titles)), out_lang_path + "/lemmatized_title.temp", False)
                write_file(word_tokenize(" ".join(px.all_content)), out_lang_path + "/tokenized_body.temp", False)
                write_file(word_tokenize(" ".join(px.all_content)), out_lang_path + "/lemmatized_body.temp", False)


def ini_mss2015_data(root_path, out_path):
    os.makedirs(out_path)
    # __processing_using_ros()
    # __processing_using_nltk()
    __stop_word = read_file("./third_part/dict/stop_list.txt")
    for cur_lang in os.listdir(root_path):
        # if cur_lang not in [""]:
        #     continue
        out_lang_path = os.path.join("%s/%s" % (out_path, cur_lang))
        lang_path = os.path.join("%s/%s" % (root_path, cur_lang))
        os.makedirs(out_lang_path)
        log.info(cur_lang)
        for cur_file in os.listdir(lang_path):
            out_dir_name = cur_file.split("_")[0]
            out_dir_path = os.path.join("%s/%s" % (out_lang_path, out_dir_name))
            os.mkdir(out_dir_path)
            content = read_file(lang_path + "/" + cur_file + "/" + cur_file + ".txt")
            write_file(content, out_dir_path + "/" + out_dir_name + ".txt", False)
            # start generate temp file
            tokenized_paper = read_file(lang_path + "/" + cur_file + "/lemmatized_body.temp")
            remove_stop = []
            segmented_paper = []
            no_bracket_str = []
            section_set = []
            tmp_str = ""
            tmp_removed_str = ""
            tmp_no_bracket_str = ""
            __brackets = False
            tmp_int = 0
            for word in tokenized_paper:
                if word == "(" or word == u"（":
                    __brackets = True
                elif word == ")" or word == u"）":
                    __brackets = False
                if word not in __stop_word:
                    tmp_removed_str += word + " "
                if __brackets:
                    tmp_str += word + " "
                    continue
                if word != "#":
                    tmp_no_bracket_str += word + " "
                    tmp_str += word + " "
                if word.endswith(".") or word in[u"。", u"！", u"？", u"；", u"#"]:
                    if tmp_removed_str != "":
                        segmented_paper.append(tmp_str)
                        remove_stop.append(tmp_removed_str)
                        no_bracket_str.append(tmp_no_bracket_str)
                        tmp_int += 1
                    if word == "#":
                        section_set.append(str(tmp_int - 1))
                    tmp_str = ""
                    tmp_removed_str = ""
                    tmp_no_bracket_str = ""
            section_set.append(str(len(segmented_paper)))
            write_file(remove_stop, out_dir_path + "/RemoveStop.temp", False)
            write_file(segmented_paper, out_dir_path + "/word_segment.temp", False)
            write_file(no_bracket_str, out_dir_path + "/word_remove_bracket.temp", False)
            titles = read_file(lang_path + "/" + cur_file + "/tokenized_title.temp")
            write_file([" ".join(titles)], out_dir_path + "/titles.temp", False)
            write_file(section_set, out_dir_path + "/sec_idx.temp", False)
            model_temp(segmented_paper, out_dir_path)
    return ""


def ini_kernel_rouge(kernel_rouge_path="../data/data_for_rouge/mss_2015_lemma/"):
    # generate gold summary split by CHAR
    ori_summary_path = "../data/MultiLing2015-MSS/multilingMss2015Eval/summary"
    for lang in os.listdir(ori_summary_path):
        lang_path = os.path.join("%s/%s/" % (ori_summary_path, lang))
        for file_name in os.listdir(lang_path):
            gold_path = kernel_rouge_path + lang + "/models/"
            if not os.path.exists(gold_path):
                os.makedirs(gold_path)
            tmp_name = lang + "/" + file_name
            abs_human = read_file(ori_summary_path + "/" + tmp_name)
            if not os.path.exists(gold_path + file_name) or True:
                if lang in ["af", "bg", "ca", "eo", "eu", "fi", "hr", "id", "ka", "ms", "sh", "sk", "sl", "sr", "vi"]:
                    write_file([" ".join(word_tokenize("\n".join(abs_human))).lower()],
                               gold_path + file_name, False)
                elif lang in ["ar", "cs", "de", "el", "en", "es", "fr", "hu", "it", "ja", "ko",
                    "nl", "no", "pl", "pt", "ro", "ru", "sv", "th", "zh"]:
                    write_file([" ".join(api.lemmatize("\n".join(abs_human))[1]).lower()],
                               gold_path + file_name, False)
                elif lang == "vi":
                    write_file([" ".join(abs_human).lower()], gold_path+file_name, False)
                else:
                    write_file([" ".join(api.tokenize("\n".join(abs_human))).lower()],
                               gold_path + file_name, False)


def ini_rouge_data(rouge_path="./data/rouge_backup",
                   name_suffix='',
                   kernel_rouge_path="./data/data_for_rouge/mss_2015_lemma"):
    """
    1. read gold summary to out_path/models
    2. create system summary dictionary out_path/systems
    3. create configure summary dictionary out_path/configure
        generate configure path
    4. create outputs dictionary out_path/output
    :param kernel_rouge_path: root rouge file back up dictionary
    :param rouge_path: out rouge dictionary path, default is './data/rouge_backup/'
    :param name_suffix: name suffix of rouge_name
    :return: rouge back up path
    """
    out_path = rouge_path + time.strftime('/%Y.%m.%d-%H.%M.%S-', time.localtime(time.time())) + name_suffix + "/"
    for lang in os.listdir(kernel_rouge_path):
        __all_conf = []
        lang_path = os.path.join(kernel_rouge_path + "/" + lang + "/models/")
        # answer dictionary
        answer_path = out_path + lang + "/systems/"
        if not os.path.exists(answer_path):
            os.makedirs(answer_path)

        # output dictionary
        result_path = out_path + lang + "/output/"
        if not os.path.exists(result_path):
            os.makedirs(result_path)

        # configure dictionary
        conf_path = out_path + lang + "/configure/"
        if not os.path.exists(conf_path):
            os.makedirs(conf_path)

        # gold dictionary
        gold_path = out_path + lang + "/models/"
        if not os.path.exists(gold_path):
            os.makedirs(gold_path)

        for file_name in os.listdir(lang_path):
            # generate gold summary split by CHAR
            tmp_name = lang + "/models/" + file_name
            abs_human = read_file(kernel_rouge_path + "/" + tmp_name)
            write_file(abs_human, gold_path + file_name, False)
            # configure dictionary
            tmp_conf_ = answer_path + file_name.split("_")[0] + ".txt " + gold_path + file_name
            __all_conf.append(tmp_conf_)
            write_file([tmp_conf_], os.path.join('%s/%s.txt' % (conf_path, file_name.split("_")[0])), False)
        write_file(__all_conf, os.path.join('%s/.configure_all_%s.txt' % (conf_path, lang)), False)
    return out_path


def ini_target_length(kernel_rouge_path="./data/data_for_rouge/mss_2015_lemma/",
                      out_path="./data/data_for_rouge/target-length/"):
    for lang in os.listdir(kernel_rouge_path):
        tmp_target_len = []
        gold_summ_path = os.path.join(kernel_rouge_path + "/" + lang + "/models/")
        for cur_file in os.listdir(gold_summ_path):
            tmp_str = cur_file.split("_")[0] + "_body.txt,"
            tmp_str += str(len("\n".join(read_file(gold_summ_path + cur_file))))
            tmp_target_len.append(tmp_str)
        write_file(tmp_target_len, out_path + lang + ".txt")


if __name__ == "__main__":
    # __processing_using_nltk()
    # __processing_using_ros()
    ini_kernel_rouge()
    # ini_mss2015_data()
    # __processing_using_nltk()
